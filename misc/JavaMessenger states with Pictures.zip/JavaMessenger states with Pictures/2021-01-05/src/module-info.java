module JavaMessenger {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.logging;
    requires jna;

    opens client.gui.customComponents.borderless to javafx.fxml;
    opens client.gui;
}