/*
 * 
 */
package client.gui.customComponents.borderless;

/**
 * This class represents a point with x and y values.
 *
 * @author Nicolas Senet-Larson
 * @author GOXR3PLUS STUDIO
 */
class Delta {
	
	/** The x. */
	Double x;
	
	/** The y. */
	Double y;
}
