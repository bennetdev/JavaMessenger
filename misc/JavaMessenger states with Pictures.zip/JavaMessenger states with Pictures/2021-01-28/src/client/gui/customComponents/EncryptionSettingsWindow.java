package client.gui.customComponents;

import javafx.scene.layout.VBox;

public class EncryptionSettingsWindow extends VBox {
    public EncryptionSettingsWindow() {
        setPrefSize(200, 200);
    }
}
