module JavaMessenger {
    requires javafx.fxml;
    requires javafx.controls;

    opens Client.gui;
}