module JavaMessenger {
    requires javafx.fxml;
    requires javafx.controls;
    requires FX.BorderlessScene;

    opens client.gui;
}